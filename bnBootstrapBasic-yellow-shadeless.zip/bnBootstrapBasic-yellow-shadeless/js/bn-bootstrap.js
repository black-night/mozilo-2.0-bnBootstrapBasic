/*!
 * bn-Bootstrap by black-night 2014
 */
$(document).ready(function(){
	//Kontaktformular Bootstrap faehig machen
	$("#contact_name").addClass("form-control");
	$("#contact_website").addClass("form-control");
	$("#contact_mail").addClass("form-control");
	$("#contact_message").addClass("form-control");
	$("#contact_calculation").addClass("form-control");
	$("#contact_privacy").addClass("form-control");
	$("#contact_privacy").css({"width":"34px","display":"inline-block"});
	$("#contact_submit").addClass("btn btn-default");	
});